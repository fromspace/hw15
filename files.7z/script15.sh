#!/bin/bash

script15.py
