#!/usr/bin/env python3

file = open('/home/user1/python/15/name.conf', 'r')
data = file.read()
print('Hello, ' + data)
